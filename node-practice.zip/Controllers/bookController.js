var express = require('express');
var mysql = require('mysql');

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "myschool"
  });

var bookController = function(){
var post = function(req,res){
    console.log(req.body.bookName);
var bookName = req.body.bookName;
var authorName = req.body.authorName;
var bookPrice = req.body.bookPrice;
var sql = "insert into books(bookName,authorName,bookPrice) values('"+bookName+"','"+authorName+"','"+bookPrice+"')";
con.query(sql,function(err,result){
      if(err)
          throw err;
             res.send(result);
}); 

}

var get = function(req,res){
    var sql = "select * from books";
        con.query(sql,function(err,book){
            if(err)
            res.status(500).send(err);
            else 
            res.json(book); 
    });
}

var myget = function(req,res){
    con.connect(function(err) {
         
       con.query("select * from books where sno="+req.params.sno, function (err, result) {
          if (err) res.status(500).send(err);
          res.send(result);
        });
       
});
}

var patch = function(req,res){
    
            con.connect(function(err) {
                var sno = req.body.sno;
                var bookName = req.body.bookName;
                var authorName = req.body.authorName;
                var bookPrice = req.body.bookPrice;
              con.query("update books set ?  where ?",[{authorName:authorName,bookName:bookName,bookPrice:bookPrice},{sno:sno}],   function (err, result) {
                 if (err) res.status(500).send(err);
                 res.send(result);
               });
              
       });
    }


    
var del  = function(req,res){
    con.connect(function(err){
       var sno = req.body.sno;
       con.query("delete from books where sno='"+sno+"'",function(err,result){
          if(err) res.status(500).send(err);
          res.send(result);

       });
          
    });
}

 return {post:post, get:get, patch:patch ,delete: del, myget:myget}

}
module.exports = bookController;    