var express = require('express');
var mysql = require('mysql');

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "myschool"
  });
 
    var bookRouter = express.Router();
    var bookController = require('../Controllers/bookController')();

    bookRouter.route('/') 
                        .post(bookController.post)
                        .get(bookController.get);


     var routes = function(){   
    bookRouter.route('/:sno')
    .get(bookController.myget)
    .patch(bookController.patch)
    .delete(bookController.delete);
   
     
    return bookRouter;
            };
module.exports = routes;