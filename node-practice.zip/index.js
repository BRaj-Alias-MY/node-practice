var express = require('express');
var app = express();
var port = process.env.PORT || 3000;
var bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
var mysql = require('mysql');


var multer = require('multer');
 
  
bookRouter = require('./Routes/bookRoutes')();
app.use('/api/books',bookRouter);
app.get('/',function(req,res){
       res.send('Gulp is running my app test on : ' + port);
});
app.listen(port);